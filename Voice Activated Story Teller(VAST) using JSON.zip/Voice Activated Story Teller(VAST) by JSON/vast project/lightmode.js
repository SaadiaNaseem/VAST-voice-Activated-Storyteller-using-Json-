$(document).ready(function () {
    // Speech recognition setup
    var recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.continuous = true;
    recognition.interimResults = true;
    var finalTranscript = '';
    var isRecording = false;

    recognition.onresult = function (event) {
        var interimTranscript = '';
        for (var i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                finalTranscript += event.results[i][0].transcript + ' ';
            } else {
                interimTranscript += event.results[i][0].transcript + ' ';
            }
        }
        $('#transcription').val(finalTranscript + interimTranscript);
    };

    $('#mic-button').click(function () {
        if (!isRecording) {
            isRecording = true;
            recognition.start();
            $('#mic-button').removeClass('not-recording').addClass('recording');
        } else {
            isRecording = false;
            recognition.stop();
            $('#mic-button').removeClass('recording').addClass('not-recording');
        }
    });

    $('#send-button').click(function () {
        var transcription = $('#transcription').val().toLowerCase().trim();
        var genre = getGenreFromInput(transcription);
        generateStory(genre);

        // Append user's message to chat history
        appendToChatHistory(transcription);
    });

    $(document).on('click', '.play-button', function () {
        var responseText = $(this).parent().text().trim();
        var speechSynthesis = window.speechSynthesis;
        var speech = new SpeechSynthesisUtterance(responseText);

        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
            $(this).html('<i class="fa fa-play"></i>');
        } else {
            speechSynthesis.speak(speech);
            $(this).html('<i class="fa fa-stop"></i>');
        }

        speech.onend = () => {
            $(this).html('<i class="fa fa-play"></i>');
        };
    });

    // Light mode toggle setup
    let isLightMode = false;
    const originalCSS = './start-screen.css';
    const lightModeCSS = './light-mode.css';

    $('#light-mode-toggle').click(function () {
        if (isLightMode) {
            $('#main-stylesheet').attr('href', originalCSS);
            $('.light-mode-1').text('Light mode');
        } else {
            $('#main-stylesheet').attr('href', lightModeCSS);
            $('.light-mode-1').text('Dark mode');
        }
        isLightMode = !isLightMode;
    });

    // Function to extract genre from input
    function getGenreFromInput(input) {
        // List of known genres
        var genres = ['fairies', 'children', 'horror', 'funny', 'fantasy', 'mystery', 'historical', 'science', 'fiction', 'sad'];

        // Check if any genre exists in the input
        for (var i = 0; i < genres.length; i++) {
            if (input.includes(genres[i])) {
                return genres[i];
            }
        }
        return '';
    }

    // Function to generate story by genre
    async function generateStory(genre) {
        if (genre === '') {
            $('#chat-container').append('<div class="chat-response">Please provide a valid genre.</div>');
            return;
        }

        // Hide initial content and show chat container
        $('#initial-content').hide();
        $('#chat-container').show();

        // Append user's message
        $('#chat-container').append('<div class="chat-message">' + genre + '</div>');

        // Fetch stories asynchronously from JSON file
        try {
            const stories = await getStoriesByGenre(genre);
            if (stories.length > 0) {
                // Randomly select a story from the chosen genre
                var randomStoryIndex = Math.floor(Math.random() * stories.length);
                var randomStory = stories[randomStoryIndex];

                // Append VAST's response with a play button
                var responseHtml = '<div class="chat-response">' +
                    randomStory.title + '<br>' + randomStory.story.join('<br>') +
                    '<button class="play-button"><i class="fa fa-play"></i></button>' +
                    '</div>';
                $('#chat-container').append(responseHtml);
            } else {
                // If no stories found for the given genre, display a message
                $('#chat-container').append('<div class="chat-response">Sorry, I couldn\'t find any stories for that genre.</div>');
            }
        } catch (error) {
            console.error(error);
            // Display an error message if fetching stories fails
            $('#chat-container').append('<div class="chat-response">Error loading stories. Please try again later.</div>');
        }

        // Clear the input field
        $('#transcription').val('');
    }

    // Function to get stories by genre
    async function getStoriesByGenre(genre) {
        try {
            const response = await fetch(`${genre}.json`);
            if (!response.ok) {
                throw new Error(`Error loading stories for ${genre}`);
            }
            const stories = await response.json();
            return stories;
        } catch (error) {
            throw error;
        }
    }

    // Function to append a message to chat history
    function appendToChatHistory(message) {
        // Append message to chat history
        $('#chat-history').append('<div class="chat-history-item">' + message + '</div>');
    }

    // Clear chat history
    $('#clear-history').click(function () {
        $('#chat-history').empty();
    });

    const newChatButton = document.querySelector('.new-chat-button');
    newChatButton.addEventListener('click', () => {
        window.location.href = 'start-screen.html';
    });
    const logoutbutton = document.querySelector('.logout');
    logoutbutton.addEventListener('click', () => {
        window.location.href = 'login.html';
    });
});
